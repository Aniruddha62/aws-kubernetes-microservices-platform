import React from 'react';
import { Link, useLocation } from 'react-router-dom';
const Navbar = () => {
  const location = useLocation();
  const links = [
    { path: '/', label: 'Dashboard' },
    { path: '/users', label: 'Users' },
    { path: '/products', label: 'Products' },
    { path: '/orders', label: 'Orders' },
    { path: '/monitoring', label: 'Monitoring' },
  ];
  return (
    <nav style={{ background: '#1a1a2e', padding: '1rem 2rem', display: 'flex', gap: '2rem', alignItems: 'center' }}>
      <span style={{ color: '#e94560', fontWeight: 'bold', fontSize: '1.2rem' }}>DevOps Platform</span>
      {links.map(link => (
        <Link key={link.path} to={link.path} style={{
          color: location.pathname === link.path ? '#e94560' : '#fff',
          textDecoration: 'none',
        }}>{link.label}</Link>
      ))}
    </nav>
  );
};
export default Navbar;
