import React from 'react';
const Orders = () => (
  <div style={{ background: '#0f3460', minHeight: '100vh', padding: '2rem', color: '#fff' }}>
    <h1>Order Management</h1>
    <p style={{ color: '#aaa' }}>Connect to order-service API to manage orders.</p>
  </div>
);
export default Orders;
