import React from 'react';
const Products = () => (
  <div style={{ background: '#0f3460', minHeight: '100vh', padding: '2rem', color: '#fff' }}>
    <h1>Product Catalog</h1>
    <p style={{ color: '#aaa' }}>Connect to product-service API to manage products.</p>
  </div>
);
export default Products;
