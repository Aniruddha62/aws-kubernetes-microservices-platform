import React from 'react';
const Users = () => (
  <div style={{ background: '#0f3460', minHeight: '100vh', padding: '2rem', color: '#fff' }}>
    <h1>User Management</h1>
    <p style={{ color: '#aaa' }}>Connect to user-service API to manage users.</p>
  </div>
);
export default Users;
