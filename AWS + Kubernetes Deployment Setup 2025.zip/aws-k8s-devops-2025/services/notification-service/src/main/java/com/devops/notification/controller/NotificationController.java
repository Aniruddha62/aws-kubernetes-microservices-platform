package com.devops.notification.controller;
import com.devops.notification.model.NotificationRequest;
import com.devops.notification.service.NotificationService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
@RestController @RequestMapping("/notifications") @RequiredArgsConstructor
public class NotificationController {
    private final NotificationService notificationService;
    @PostMapping("/send") public ResponseEntity<String> send(@RequestBody NotificationRequest request) {
        notificationService.sendNotification(request);
        return ResponseEntity.ok("Notification sent successfully");
    }
    @GetMapping("/health") public ResponseEntity<String> health() { return ResponseEntity.ok("Notification Service UP"); }
}
