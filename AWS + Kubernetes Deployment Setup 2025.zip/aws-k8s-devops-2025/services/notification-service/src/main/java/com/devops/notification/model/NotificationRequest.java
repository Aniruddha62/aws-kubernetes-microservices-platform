package com.devops.notification.model;
import lombok.*;
@Data @NoArgsConstructor @AllArgsConstructor
public class NotificationRequest {
    private String to;
    private String subject;
    private String message;
    private NotificationType type = NotificationType.EMAIL;
    public enum NotificationType { EMAIL, SMS, PUSH }
}
