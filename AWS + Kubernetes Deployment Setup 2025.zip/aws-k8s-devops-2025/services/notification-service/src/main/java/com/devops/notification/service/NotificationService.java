package com.devops.notification.service;
import com.devops.notification.model.NotificationRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;
@Service @RequiredArgsConstructor @Slf4j
public class NotificationService {
    private final JavaMailSender mailSender;
    public void sendNotification(NotificationRequest request) {
        switch (request.getType()) {
            case EMAIL -> sendEmail(request);
            case SMS -> log.info("SMS to {}: {}", request.getTo(), request.getMessage());
            case PUSH -> log.info("PUSH to {}: {}", request.getTo(), request.getMessage());
        }
    }
    private void sendEmail(NotificationRequest request) {
        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setTo(request.getTo());
            message.setSubject(request.getSubject());
            message.setText(request.getMessage());
            mailSender.send(message);
            log.info("Email sent to: {}", request.getTo());
        } catch (Exception e) {
            log.error("Failed to send email: {}", e.getMessage());
        }
    }
}
