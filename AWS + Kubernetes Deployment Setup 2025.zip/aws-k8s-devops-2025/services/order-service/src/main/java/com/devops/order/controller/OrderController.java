package com.devops.order.controller;
import com.devops.order.model.Order;
import com.devops.order.service.OrderService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController @RequestMapping("/orders") @RequiredArgsConstructor
public class OrderController {
    private final OrderService orderService;
    @PostMapping public ResponseEntity<Order> createOrder(@RequestBody Order order) {
        return ResponseEntity.status(HttpStatus.CREATED).body(orderService.createOrder(order));
    }
    @GetMapping public ResponseEntity<List<Order>> getAll() { return ResponseEntity.ok(orderService.getAllOrders()); }
    @GetMapping("/{id}") public ResponseEntity<Order> getById(@PathVariable Long id) {
        return orderService.getOrderById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }
    @GetMapping("/user/{userId}") public ResponseEntity<List<Order>> getByUser(@PathVariable Long userId) {
        return ResponseEntity.ok(orderService.getOrdersByUser(userId));
    }
    @PatchMapping("/{id}/status") public ResponseEntity<Order> updateStatus(@PathVariable Long id, @RequestParam Order.OrderStatus status) {
        return ResponseEntity.ok(orderService.updateOrderStatus(id, status));
    }
    @DeleteMapping("/{id}") public ResponseEntity<Void> cancel(@PathVariable Long id) {
        orderService.cancelOrder(id); return ResponseEntity.noContent().build();
    }
}
