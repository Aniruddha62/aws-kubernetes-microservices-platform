package com.devops.order.service;
import com.devops.order.model.Order;
import com.devops.order.repository.OrderRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service @RequiredArgsConstructor
public class OrderService {
    private final OrderRepository orderRepository;

    public Order createOrder(Order order) {
        if (order.getItems() != null) {
            BigDecimal total = order.getItems().stream()
                .map(item -> item.getUnitPrice().multiply(new BigDecimal(item.getQuantity())))
                .reduce(BigDecimal.ZERO, BigDecimal::add);
            order.setTotalAmount(total);
        }
        return orderRepository.save(order);
    }
    public List<Order> getAllOrders() { return orderRepository.findAll(); }
    public Optional<Order> getOrderById(Long id) { return orderRepository.findById(id); }
    public List<Order> getOrdersByUser(Long userId) { return orderRepository.findByUserId(userId); }
    public Order updateOrderStatus(Long id, Order.OrderStatus status) {
        Order order = orderRepository.findById(id).orElseThrow(() -> new RuntimeException("Order not found"));
        order.setStatus(status);
        order.setUpdatedAt(LocalDateTime.now());
        return orderRepository.save(order);
    }
    public void cancelOrder(Long id) { updateOrderStatus(id, Order.OrderStatus.CANCELLED); }
}
