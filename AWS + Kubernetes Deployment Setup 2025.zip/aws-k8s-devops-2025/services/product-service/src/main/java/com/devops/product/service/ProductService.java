package com.devops.product.service;
import com.devops.product.model.Product;
import com.devops.product.repository.ProductRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
@Service @RequiredArgsConstructor
public class ProductService {
    private final ProductRepository productRepository;
    public Product createProduct(Product product) { return productRepository.save(product); }
    public List<Product> getAllProducts() { return productRepository.findAll(); }
    public Optional<Product> getProductById(Long id) { return productRepository.findById(id); }
    public List<Product> getProductsByCategory(String category) { return productRepository.findByCategory(category); }
    public List<Product> searchProducts(String name) { return productRepository.findByNameContainingIgnoreCase(name); }
    public Product updateProduct(Long id, Product details) {
        Product product = productRepository.findById(id).orElseThrow(() -> new RuntimeException("Product not found"));
        product.setName(details.getName());
        product.setDescription(details.getDescription());
        product.setPrice(details.getPrice());
        product.setStock(details.getStock());
        product.setCategory(details.getCategory());
        return productRepository.save(product);
    }
    public void deleteProduct(Long id) { productRepository.deleteById(id); }
}
